class KeyConstant {
  static const username = 'username';
  static const bankAccount = 'bankAccount';
  static const saldo = 'saldo';
  static const token = 'token';
}
