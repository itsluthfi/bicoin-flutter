package com.example.dev_coinku

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
